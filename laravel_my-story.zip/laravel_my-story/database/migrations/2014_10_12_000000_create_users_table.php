<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();
            $table->string('password');
            $table->string('image')->nullable();
            $table->string('name');
            $table->date('date_naissance');
            $table->string('lieux_naissance');
            $table->string('sexe');
            $table->string('profession')->nullable();
            $table->integer('statut')->default(1);
            $table->string('code_mere')->nullable();
            $table->string('code_pere')->nullable();
            $table->foreign('code_mere')->references('code')->on('users');
            $table->foreign('code_pere')->references('code')->on('users');
            $table->foreignId('id_employer')->nullable()->constrained('employers');
            $table->foreignId('id_mairie')->nullable()->constrained('mairies');
            $table->foreignId('id_hopital')->nullable()->constrained('hopitals');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
