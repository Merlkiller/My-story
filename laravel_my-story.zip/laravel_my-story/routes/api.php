<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\userController;
use App\Http\Controllers\HopitalController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::post('/register',[userController::class,'register']);
Route::post('/login',[userController::class,'login']);
Route::post('/createhosto',[HopitalController::class,'addhopittal']);
Route::delete('/deletehoste/{id}',[HopitalController::class,'drophopital']);
Route::get('/gethosto',[HopitalController::class,'gethopital']);
Route::post('/updatehopital/{id}',[HopitalController::class,'updatehopital']);


Route::get('/arbre',[userController::class,'arbre']);


Route::middleware('auth:api')->group(function () {
    Route::get('/info',[userController::class,'info']);
});



Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
