<?php

namespace App\Http\Controllers;

use App\Models\Hopital;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class HopitalController extends Controller
{
    

    public function addhopittal(Request $request){
        $hopital = new Hopital;
        $hopital->nom = $request->nom;
        $hopital->save();
        Cache::forget('hopital');
        $hopital = Cache::remember('hopital',10,function (){
            return Hopital::all();
        });
        return response()->json($hopital,200);
    }
    public function gethopital(){
        $hopital = Cache::remember('hopital',10,function (){
            return Hopital::all();
        });
        return response()->json($hopital,200);
    }

    public function drophopital($id){
        Hopital::find($id)->delete();
        Cache::forget('hopital');
        $hopital = Cache::remember('hopital',10,function (){
            return Hopital::all();
        });
        return response()->json($hopital,200);
    }

    public function updatehopital($id,Request $request){
        $hopital = Hopital::find($id);
        $hopital->nom = $request->nom;
        $hopital->update();
        Cache::forget('hopital');
        $hopital = Cache::remember('hopital',10,function (){
            return Hopital::all();
        });
        return response()->json($hopital,200);
    }

}
