<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Employer;
use Illuminate\Http\Request;

class userController extends Controller
{

    public function register(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|max:255',
            'code' => 'required',
            'date_naissance' => 'required',
            'lieux_naissance' => 'required',
            'sexe' => 'required',
            'profession',
            'password',
            'statut',
            'code_mere',
            'code_pere',
            'id_employer',
            'id_mairie' => 'required',
            'id_hopital',
        ]);

        $data['password'] = bcrypt($request->code);

        $user = User::create($data);

        $token = $user->createToken('Client ID')->accessToken;

        return response()->json([ 'user' => $user, 'token' => $token]);

    }

    public function login(Request $request)
    {
        $data = [
            'name' => $request->name,
            'password' => $request->code
        ];

        if (auth()->attempt($data)) {
            $user = User::where('name', $request->name)->get();
           
            if ($user[0]->statut == 1) {
                $token = auth()->user()->createToken('Laravel Password Grant Client')->accessToken;

                $admin = Employer::where('code', $user[0]->code)->get();

                if (count($admin) == 1) {

                    return response()->json(['token' => $token, 'admin' => true], 200);
                }
                else{
                    return response()->json(['token' => $token, 'admin' => false], 200);
                }

                
            }else{
                return response()->json(['yo' => 'Unauthorised'], 200);
            }
        } else {
            return response()->json(['error' => 'Unauthorised'], 200);
        }
    }

    public function arbre(){

        $user = User::find(1);


        $pere = User::where('code', $user->code_pere)->get();
        $mere = User::where('code', $user->code_mere)->get();

        $frere = [];
        $oncle_maternel = [];
        $oncle_paternel = [];
        $grand_mere_maternel = [];
        $grand_pere_maternel = [];
        $grand_mere_paternel = [];
        $grand_pere_paternel = [];

        if (count($pere) == 1) {
            $oncle_paternel = User::where('code_pere', $pere[0]->code_pere)->where('code_mere', $pere[0]->code_mere)->where('code', '!=', $pere[0]->code)->get();

            $grand_pere_paternel = User::where('code', $pere[0]->code_pere)->get();

            $grand_mere_paternel = User::where('code', $pere[0]->code_mere)->get();
        }

        if (count($mere) == 1) {

            $oncle_maternel = User::where('code_pere', $mere[0]->code_pere)->where('code_mere', $mere[0]->code_mere)->where('code', '!=', $mere[0]->code)->get();

            $frere = User::where('code_pere', $user->code_pere)->where('code_mere', $user->code_mere)->where('code', '!=', $user->code)->get();

            $grand_pere_maternel = User::where('code', $mere[0]->code_pere)->get();

            $grand_mere_maternel = User::where('code', $mere[0]->code_mere)->get();
        }

        
        


        return response()->json([
            'user' => $user,
            'pere' => $pere,
            'mere' => $mere,
            'frere' => $frere,
            'grand_pere_paternel' => $grand_pere_paternel,
            'grand_pere_maternel' => $grand_pere_maternel,
            'grand_mere_paternel' => $grand_mere_paternel,
            'grand_mere_maternel' => $grand_mere_maternel,
        ]);

    }

}
