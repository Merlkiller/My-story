<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MairieController extends Controller
{
    //
}
